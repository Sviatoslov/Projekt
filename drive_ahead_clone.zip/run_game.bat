@echo off
javac DriveAheadClone.java
java DriveAheadClone
pause
