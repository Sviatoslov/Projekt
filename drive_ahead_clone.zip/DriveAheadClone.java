import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DriveAheadClone extends JPanel implements ActionListener, KeyListener {
    // Розміри вікна і “ґрунту”
    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;
    private static final int GROUND_Y = HEIGHT - 100;

    private Timer timer;
    private Car car1, car2;
    private boolean gameOver = false;

    public DriveAheadClone() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(new Color(135, 206, 235)); // небо

        // Створюємо дві машини
        car1 = new Car(100, GROUND_Y - 30, Color.RED, KeyEvent.VK_A, KeyEvent.VK_D, KeyEvent.VK_W);
        car2 = new Car(WIDTH - 160, GROUND_Y - 30, Color.BLUE, KeyEvent.VK_LEFT, KeyEvent.VK_RIGHT, KeyEvent.VK_UP);

        timer = new Timer(16, this); // ~60 FPS
        timer.start();

        setFocusable(true);
        addKeyListener(this);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Ґрунт
        g.setColor(new Color(50, 205, 50));
        g.fillRect(0, GROUND_Y, WIDTH, HEIGHT - GROUND_Y);

        // Машини
        car1.draw(g);
        car2.draw(g);

        if (gameOver) {
            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", Font.BOLD, 48));
            String msg = "Game Over!";
            int msgW = g.getFontMetrics().stringWidth(msg);
            g.drawString(msg, (WIDTH - msgW) / 2, HEIGHT / 2);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!gameOver) {
            car1.update();
            car2.update();
            // Перевірка зіткнення
            if (car1.getBounds().intersects(car2.getBounds())) {
                gameOver = true;
            }
        }
        repaint();
    }

    // KeyListener
    @Override
    public void keyPressed(KeyEvent e) {
        car1.keyPressed(e);
        car2.keyPressed(e);
    }
    @Override
    public void keyReleased(KeyEvent e) {
        car1.keyReleased(e);
        car2.keyReleased(e);
    }
    @Override public void keyTyped(KeyEvent e) {}

    // Головний метод
    public static void main(String[] args) {
        JFrame frame = new JFrame("Drive Ahead Clone");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.add(new DriveAheadClone());
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    // Внутрішній клас Car
    private static class Car {
        // Фізика
        private static final double GRAVITY = 0.6;
        private static final double FRICTION = 0.9;
        private static final double ACCEL = 0.5;
        private static final double JUMP_VEL = 15;

        int width = 60, height = 30;
        double x, y, velX = 0, velY = 0;
        boolean onGround = false;
        Color color;

        // Контролі
        int keyLeft, keyRight, keyJump;
        boolean leftPressed = false, rightPressed = false, jumpPressed = false;

        Car(int x, int y, Color color, int keyLeft, int keyRight, int keyJump) {
            this.x = x; this.y = y;
            this.color = color;
            this.keyLeft = keyLeft;
            this.keyRight = keyRight;
            this.keyJump = keyJump;
        }

        void update() {
            // Вхідні дії
            if (rightPressed) velX += ACCEL;
            if (leftPressed)  velX -= ACCEL;
            if (jumpPressed && onGround) {
                velY = -JUMP_VEL;
                onGround = false;
            }

            // Гравітація
            velY += GRAVITY;

            // Рух
            x += velX;
            y += velY;

            // Колізія з “ґрунтом”
            if (y + height >= GROUND_Y) {
                y = GROUND_Y - height;
                velY = 0;
                onGround = true;
                velX *= FRICTION;
            } else {
                onGround = false;
            }
        }

        void draw(Graphics g) {
            g.setColor(color);
            g.fillRect((int)x, (int)y, width, height);
        }

        Rectangle getBounds() {
            return new Rectangle((int)x, (int)y, width, height);
        }

        void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == keyLeft)  leftPressed  = true;
            if (e.getKeyCode() == keyRight) rightPressed = true;
            if (e.getKeyCode() == keyJump)  jumpPressed  = true;
        }

        void keyReleased(KeyEvent e) {
            if (e.getKeyCode() == keyLeft)  leftPressed  = false;
            if (e.getKeyCode() == keyRight) rightPressed = false;
            if (e.getKeyCode() == keyJump)  jumpPressed  = false;
        }
    }
}
