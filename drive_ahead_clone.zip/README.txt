Drive Ahead Clone Java Project

Contents:
- DriveAheadClone.java: Source code for the two-player Drive Ahead clone.
- run_game.bat: Batch script to compile and run the game with pause.

Instructions:
1. Extract the archive.
2. Open a Command Prompt in this directory.
3. Execute run_game.bat to compile and start the game.
